
TumorSegmentation
===================================================================

This dataset was exported via roboflow.com on August 19, 2023

The dataset includes 2146 images.
Tumors are annotated in COCO Segmentation format.
====================================================================

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x640 (Stretch)
* No image augmentation techniques were applied.
====================================================================

Provided by Roboflow
License: CC BY 4.0


